<?php
$a=rand(6,9);
$b=rand(5,9);
if($a!=0){
    $x=-($b)/$a;
    echo"soit l'equation: {$a}x + $b <br> la solution est $x";
}
?>